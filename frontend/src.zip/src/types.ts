export interface AttendanceData {
  year: string;
  attendanceRate: number | null;
  absences: number | null;
  excused: number | null;
  total: number;
  lates?: number | null;
  isPredicted?: boolean;
}

export interface Student {
  id: string;
  grade: string;
  schoolName: string;
  districtName: string;
}

export interface RiskCategory {
  level: 'Low' | 'Medium' | 'High';
  color: string;
  description: string;
}
